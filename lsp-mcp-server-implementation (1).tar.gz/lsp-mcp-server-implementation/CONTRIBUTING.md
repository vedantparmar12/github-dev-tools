# Contributing to LSP-MCP Server

Thank you for your interest in contributing! This document provides guidelines and instructions for contributing.

## Table of Contents

1. [Code of Conduct](#code-of-conduct)
2. [Getting Started](#getting-started)
3. [Development Setup](#development-setup)
4. [Making Changes](#making-changes)
5. [Testing](#testing)
6. [Submitting Changes](#submitting-changes)
7. [Coding Standards](#coding-standards)
8. [Architecture Guidelines](#architecture-guidelines)

## Code of Conduct

- Be respectful and constructive
- Welcome newcomers
- Focus on what is best for the community
- Show empathy towards other community members

## Getting Started

### Prerequisites

- Node.js 18.x or higher
- npm 9.x or higher
- Redis 6.x or higher
- Git
- Basic understanding of TypeScript and LSP

### Fork and Clone

```bash
# Fork the repository on GitHub

# Clone your fork
git clone https://github.com/YOUR_USERNAME/LSP-MCP.git
cd LSP-MCP

# Add upstream remote
git remote add upstream https://github.com/vedantparmar12/LSP-MCP.git
```

## Development Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Start Redis

```bash
# Using Docker
docker run -d -p 6379:6379 redis:alpine

# Or install locally
# macOS: brew install redis && brew services start redis
# Ubuntu: sudo apt install redis-server
```

### 3. Configure Environment

```bash
cp .env.example .env
# Edit .env with your settings
```

### 4. Start Development Server

```bash
npm run dev -- /path/to/test/workspace
```

## Making Changes

### Branch Naming Convention

- `feature/description` - New features
- `fix/description` - Bug fixes
- `docs/description` - Documentation updates
- `refactor/description` - Code refactoring
- `perf/description` - Performance improvements
- `test/description` - Test additions/updates

**Example:**
```bash
git checkout -b feature/add-python-lsp-support
```

### Commit Message Format

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation only
- `style`: Code style changes (formatting)
- `refactor`: Code refactoring
- `perf`: Performance improvement
- `test`: Adding tests
- `chore`: Build/tooling changes

**Examples:**
```
feat(cache): add content-hash based invalidation

Implements content-hash validation to prevent serving
stale cache entries when file content changes.

Closes #42
```

```
fix(security): prevent path traversal in file access

Resolves symlink before validation to prevent escape
from workspace boundaries.

Fixes #89
```

### What to Contribute

**High Priority:**
- Bug fixes
- Security improvements
- Performance optimizations
- Test coverage
- Documentation improvements

**Medium Priority:**
- New LSP server support (Python, Go, Rust)
- Additional cache strategies
- Monitoring/observability features

**Please Discuss First:**
- Major architectural changes
- Breaking API changes
- New major dependencies

## Testing

### Running Tests

```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run with coverage
npm run test:coverage
```

### Writing Tests

Place tests in `tests/` directory:

```typescript
// tests/my-feature.test.ts
import { MyFeature } from '../src/my-feature';

describe('MyFeature', () => {
  test('should do something', () => {
    const feature = new MyFeature();
    expect(feature.doSomething()).toBe(expected);
  });
});
```

### Test Requirements

- All new features must have tests
- Bug fixes must include regression tests
- Aim for >80% code coverage
- Tests must pass before PR merge

## Submitting Changes

### Before Submitting

1. **Update from upstream**
   ```bash
   git fetch upstream
   git rebase upstream/main
   ```

2. **Run tests**
   ```bash
   npm test
   ```

3. **Run linter**
   ```bash
   npm run lint
   ```

4. **Build successfully**
   ```bash
   npm run build
   ```

5. **Update documentation** if needed

### Creating Pull Request

1. **Push to your fork**
   ```bash
   git push origin feature/your-feature
   ```

2. **Create PR on GitHub**
   - Use descriptive title
   - Fill out PR template
   - Link related issues
   - Add screenshots if UI changes
   - Mark as draft if work in progress

3. **PR Checklist**
   - [ ] Tests pass
   - [ ] Linter passes
   - [ ] Documentation updated
   - [ ] CHANGELOG.md updated (if applicable)
   - [ ] No merge conflicts
   - [ ] Commits are clean and logical

### PR Review Process

1. Automated checks must pass
2. At least one maintainer approval required
3. Address review feedback
4. Squash commits if requested
5. Maintainer will merge when ready

## Coding Standards

### TypeScript Style Guide

**Use strict TypeScript:**
```typescript
// ✅ Good - Explicit types
function processFile(filePath: string): Promise<string> {
  return fs.readFile(filePath, 'utf-8');
}

// ❌ Bad - Implicit any
function processFile(filePath) {
  return fs.readFile(filePath, 'utf-8');
}
```

**Use async/await:**
```typescript
// ✅ Good
async function getData() {
  const result = await fetchData();
  return result;
}

// ❌ Bad
function getData() {
  return fetchData().then(result => result);
}
```

**Handle errors properly:**
```typescript
// ✅ Good
try {
  const result = await riskyOperation();
  return result;
} catch (error) {
  logger.error('Operation failed:', error);
  throw new CustomError('Failed to process', { cause: error });
}

// ❌ Bad
const result = await riskyOperation(); // Unhandled rejection
```

**Use meaningful names:**
```typescript
// ✅ Good
const semanticGraph = new SemanticGraphBuilder(rootPath);
const cacheHitRate = stats.l1Hits / stats.total;

// ❌ Bad
const sg = new SemanticGraphBuilder(rootPath);
const chr = stats.l1Hits / stats.total;
```

### File Organization

```
src/
├── module-name/
│   ├── index.ts          # Public API exports
│   ├── implementation.ts # Main implementation
│   ├── types.ts          # Type definitions
│   └── utils.ts          # Helper functions
```

### Import Order

```typescript
// 1. Node built-ins
import * as fs from 'fs/promises';
import * as path from 'path';

// 2. External dependencies
import { LRUCache } from 'lru-cache';
import Redis from 'ioredis';

// 3. Internal modules
import { SemanticGraph } from '../graph/semantic-graph';
import { MultiLayerCache } from '../cache/multi-layer-cache';

// 4. Types
import type { CacheConfig } from './types';
```

### Documentation

**Document public APIs:**
```typescript
/**
 * Validates file path is within allowed boundaries
 * 
 * @param filePath - Path to validate
 * @throws {Error} If path is outside workspace or blocked
 * @returns void
 * 
 * @example
 * ```typescript
 * sandbox.validateOrThrow('/workspace/src/index.ts'); // OK
 * sandbox.validateOrThrow('/etc/passwd'); // Throws
 * ```
 */
validateOrThrow(filePath: string): void {
  // Implementation
}
```

**Add inline comments for complex logic:**
```typescript
// PageRank-style importance calculation
// Each node distributes importance to its dependencies
for (let i = 0; i < iterations; i++) {
  // ... complex algorithm ...
}
```

## Architecture Guidelines

### Adding New Features

1. **Design first**
   - Document the design
   - Get feedback on the approach
   - Consider alternatives

2. **Keep it modular**
   - Single responsibility principle
   - Clear interfaces
   - Minimal dependencies

3. **Follow existing patterns**
   - Study similar features
   - Use same architectural style
   - Maintain consistency

### Security Considerations

**Always validate input:**
```typescript
function processUserInput(input: string): void {
  // Validate
  if (!isValid(input)) {
    throw new ValidationError('Invalid input');
  }
  
  // Sanitize
  const sanitized = sanitize(input);
  
  // Process
  return process(sanitized);
}
```

**Use security features:**
```typescript
// File access
sandbox.validateOrThrow(filePath);
const content = await fs.readFile(filePath);

// Logging (no sensitive data)
auditor.logFileAccess(pid, filePath, 'read', allowed);
```

### Performance Considerations

**Use caching appropriately:**
```typescript
// Check cache first
const cached = await cache.get(key);
if (cached) return cached;

// Expensive operation
const result = await expensiveOperation();

// Cache result
await cache.set(key, result);
```

**Avoid blocking:**
```typescript
// ✅ Good - Non-blocking
async function processFiles(files: string[]): Promise<void> {
  await Promise.all(files.map(f => processFile(f)));
}

// ❌ Bad - Blocking
async function processFiles(files: string[]): Promise<void> {
  for (const file of files) {
    await processFile(file); // Blocks each iteration
  }
}
```

## Common Tasks

### Adding a New LSP Server

1. Update `LSPClient` configuration
2. Add language detection in `IntelligentWarmup`
3. Update documentation
4. Add tests
5. Update examples

### Adding a New Cache Layer

1. Implement cache interface
2. Integrate in `MultiLayerCache`
3. Add configuration options
4. Update documentation
5. Add tests

### Improving Security

1. Identify threat
2. Design mitigation
3. Implement securely
4. Add tests (including negative tests)
5. Update SECURITY.md
6. Add audit logging

## Getting Help

- 💬 Discussions: Use GitHub Discussions for questions
- 🐛 Issues: Report bugs via GitHub Issues
- 📧 Email: vedantparmarsingh@gmail.com for security issues

## Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Mentioned in release notes
- Credited in documentation (if applicable)

Thank you for contributing! 🎉
