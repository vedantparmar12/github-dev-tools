# Security Policy

## Overview

LSP-MCP Server implements comprehensive security measures to protect against unauthorized access, resource abuse, and common attack vectors.

## Security Features

### 1. File Access Control

**What it does:** Restricts file access to workspace boundaries
**Implementation:** `src/security/sandbox.ts`

- ✅ Validates all file paths before access
- ✅ Blocks access to system directories (`/etc`, `/var`, `/usr`)
- ✅ Blocks access to sensitive user directories (`~/.ssh`, `~/.aws`)
- ✅ Only allows access within workspace root

**Example:**
```typescript
sandbox.validateOrThrow('/workspace/src/index.ts'); // ✅ Allowed
sandbox.validateOrThrow('/etc/passwd'); // ❌ Throws error
```

### 2. Resource Limits

**What it does:** Prevents resource exhaustion attacks
**Implementation:** `src/security/resource-limiter.ts`

- ✅ Memory limit: 2GB (configurable)
- ✅ CPU limit: 50% of single core (configurable)
- ✅ File descriptor limit: 1000
- ✅ Process limit: 10

**Configuration:**
```yaml
security:
  resourceLimits:
    maxMemoryMB: 2048
    maxCPUPercent: 50
```

### 3. Process Sandboxing

**What it does:** Isolates LSP server processes
**Implementation:** `src/security/sandbox.ts`

**Platform Support:**
- **Linux:** Uses `unshare` (namespaces) + `chroot`
- **macOS:** Uses `sandbox-exec`
- **Docker:** Recommended for production (full isolation)

**Docker Sandboxing (Recommended):**
```bash
docker-compose up lsp-mcp
```

Benefits:
- Network isolation (`--network=none`)
- Read-only filesystem
- Resource limits enforced by cgroups
- User namespace isolation

### 4. Audit Logging

**What it does:** Tracks all security-relevant events
**Implementation:** `src/security/auditor.ts`

**Logged Events:**
- File access attempts (allowed/denied)
- Network connection attempts
- Resource limit violations
- Permission denials
- Process spawns

**Log Location:** `/tmp/lsp-mcp-security.log`

**Example Log Entry:**
```json
{
  "level": "warn",
  "message": "Security event",
  "event_type": "file_access",
  "pid": 12345,
  "severity": "medium",
  "timestamp": "2025-12-28T10:30:00.000Z",
  "path": "/etc/passwd",
  "action": "read",
  "allowed": false
}
```

### 5. Network Restrictions

**What it does:** Blocks outbound network connections
**Implementation:** Docker/sandbox configuration

- ✅ No network access by default
- ✅ Whitelist required for specific endpoints
- ✅ All network attempts are logged

## Threat Model

### Threats Mitigated

1. **Path Traversal Attacks**
   - Mitigation: File path validation
   - Status: ✅ Protected

2. **Resource Exhaustion (DoS)**
   - Mitigation: Resource limits + monitoring
   - Status: ✅ Protected

3. **Privilege Escalation**
   - Mitigation: Non-root user, sandboxing
   - Status: ✅ Protected

4. **Data Exfiltration**
   - Mitigation: Network blocking, file access control
   - Status: ✅ Protected

5. **Code Injection**
   - Mitigation: Input validation, TypeScript type safety
   - Status: ✅ Protected

### Threats NOT Fully Mitigated

1. **Supply Chain Attacks**
   - Risk: Compromised npm packages
   - Mitigation: Regular `npm audit`, dependency scanning
   - Action Required: Enable Dependabot in GitHub

2. **Side-Channel Attacks**
   - Risk: Timing attacks, cache timing
   - Mitigation: Not currently addressed
   - Impact: Low (not applicable to LSP use case)

## Security Configuration

### Minimal Security (Development)

```yaml
security:
  enabled: true
  fileAccess:
    enabled: true
  resourceLimits:
    maxMemoryMB: 4096
  sandbox:
    enabled: false  # Sandbox disabled for development
  audit:
    enabled: true
```

### Recommended Security (Production)

```yaml
security:
  enabled: true
  fileAccess:
    enabled: true
    allowedPaths:
      - ${WORKSPACE_ROOT}
    blockedPaths:
      - /etc
      - /var
      - ~/.ssh
      - ~/.aws
  resourceLimits:
    maxMemoryMB: 2048
    maxCPUPercent: 50
    maxFileDescriptors: 1000
    maxProcesses: 10
  sandbox:
    enabled: true
    method: docker  # Use Docker for best isolation
  audit:
    enabled: true
    logLevel: info
    alertOnCritical: true
```

### Maximum Security (Paranoid)

Use Docker with:
- Read-only root filesystem
- No network access
- Minimal capabilities
- Security profiles (AppArmor/SELinux)

```bash
docker run \
  --rm -i \
  --read-only \
  --network=none \
  --memory=2g \
  --cpus=0.5 \
  --security-opt=no-new-privileges:true \
  --cap-drop=ALL \
  -v /path/to/workspace:/workspace:ro \
  lsp-mcp-server
```

## Vulnerability Reporting

### Reporting a Vulnerability

**DO NOT** create a public GitHub issue for security vulnerabilities.

Instead:
1. Email: vedantparmarsingh@gmail.com
2. Subject: "[SECURITY] LSP-MCP Vulnerability Report"
3. Include:
   - Description of vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)

### Response Timeline

- **Acknowledgment:** Within 48 hours
- **Initial Assessment:** Within 1 week
- **Fix Timeline:** Depends on severity
  - Critical: 1-3 days
  - High: 1-2 weeks
  - Medium: 2-4 weeks
  - Low: Next release

### Disclosure Policy

- Coordinated disclosure preferred
- 90-day disclosure timeline after fix
- Credit given to reporters (if desired)

## Security Best Practices

### For Developers

1. **Always validate input**
   ```typescript
   // ✅ Good
   sandbox.validateOrThrow(filePath);
   const content = await fs.readFile(filePath);
   
   // ❌ Bad
   const content = await fs.readFile(filePath);
   ```

2. **Use TypeScript strict mode**
   ```json
   {
     "compilerOptions": {
       "strict": true,
       "noImplicitAny": true
     }
   }
   ```

3. **Never log sensitive data**
   ```typescript
   // ✅ Good
   logger.info('User authenticated', { userId: user.id });
   
   // ❌ Bad
   logger.info('User authenticated', { password: user.password });
   ```

4. **Regular dependency updates**
   ```bash
   npm audit
   npm audit fix
   ```

### For Operators

1. **Use Docker in production**
2. **Enable all security features**
3. **Monitor security logs**
4. **Regular security audits**
5. **Keep dependencies updated**
6. **Use secrets management (not .env files)**

## Security Checklist

Before deploying to production:

- [ ] Docker sandboxing enabled
- [ ] Resource limits configured
- [ ] File access validation enabled
- [ ] Audit logging enabled
- [ ] Network access blocked
- [ ] Running as non-root user
- [ ] Read-only filesystem
- [ ] Security monitoring in place
- [ ] Secrets not in code/config
- [ ] Dependencies up to date
- [ ] `npm audit` shows no vulnerabilities
- [ ] Security policies documented
- [ ] Incident response plan in place

## Known Security Considerations

### 1. LSP Server Trust

LSP servers run with workspace access. A malicious LSP server could:
- Read workspace files
- Execute code within sandbox
- Consume resources up to limits

**Mitigation:** Only use trusted LSP servers from official sources.

### 2. Redis Security

Redis is used for L2 cache. Ensure:
- Redis requires authentication
- Redis not exposed to internet
- Redis runs on private network

**Configuration:**
```yaml
redis:
  url: redis://:password@localhost:6379
```

### 3. Workspace Boundaries

Symbolic links could potentially escape workspace.

**Mitigation:** Resolve symlinks before validation:
```typescript
const resolved = path.resolve(filePath);
sandbox.validateOrThrow(resolved);
```

## Compliance

### GDPR Considerations

- No personal data collected by default
- Workspace data stays local
- Audit logs may contain file paths
- Configure log retention appropriately

### SOC 2 Considerations

- Audit logging: ✅ Implemented
- Access controls: ✅ Implemented
- Encryption at rest: ⚠️  Not implemented (use encrypted filesystems)
- Encryption in transit: ⚠️  Not applicable (local process)

## Updates

This security policy is reviewed quarterly.

**Last Updated:** 2025-12-28
**Next Review:** 2026-03-28

## References

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [CWE/SANS Top 25](https://cwe.mitre.org/top25/)
- [Docker Security](https://docs.docker.com/engine/security/)
- [Node.js Security Best Practices](https://nodejs.org/en/docs/guides/security/)
