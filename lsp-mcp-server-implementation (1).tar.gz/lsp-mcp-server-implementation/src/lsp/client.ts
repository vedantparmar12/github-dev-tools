import {
  LanguageClient,
  LanguageClientOptions,
  ServerOptions,
  TransportKind,
} from 'vscode-languageclient/node';
import { spawn, ChildProcess } from 'child_process';
import * as path from 'path';

export interface LSPClientConfig {
  command: string;
  args: string[];
  workspaceRoot: string;
}

export class LSPClient {
  private client: LanguageClient | null = null;
  private process: ChildProcess | null = null;
  public lastUsed: number = Date.now();
  
  constructor(private config: LSPClientConfig) {}
  
  async start(): Promise<void> {
    console.log(`Starting LSP: ${this.config.command} ${this.config.args.join(' ')}`);
    
    const serverOptions: ServerOptions = {
      command: this.config.command,
      args: this.config.args,
      transport: TransportKind.stdio,
    };
    
    const clientOptions: LanguageClientOptions = {
      documentSelector: [
        { scheme: 'file', language: 'typescript' },
        { scheme: 'file', language: 'typescriptreact' },
        { scheme: 'file', language: 'javascript' },
        { scheme: 'file', language: 'javascriptreact' },
      ],
      synchronize: {
        fileEvents: [],
      },
      initializationOptions: {},
      workspaceFolder: {
        uri: `file://${this.config.workspaceRoot}`,
        name: path.basename(this.config.workspaceRoot),
        index: 0,
      },
    };
    
    this.client = new LanguageClient(
      'lsp-mcp',
      'LSP-MCP Server',
      serverOptions,
      clientOptions
    );
    
    await this.client.start();
    this.lastUsed = Date.now();
    console.log('LSP client started successfully');
  }
  
  async request<T>(method: string, params: any): Promise<T> {
    if (!this.client) {
      throw new Error('LSP client not started');
    }
    
    this.lastUsed = Date.now();
    
    try {
      const result = await this.client.sendRequest(method, params);
      return result as T;
    } catch (error) {
      console.error(`LSP request failed: ${method}`, error);
      throw error;
    }
  }
  
  async shutdown(): Promise<void> {
    if (this.client) {
      console.log('Shutting down LSP client...');
      await this.client.stop();
      this.client = null;
    }
    
    if (this.process) {
      this.process.kill();
      this.process = null;
    }
  }
  
  // Convenience methods for common LSP requests
  
  async initialize(params: any): Promise<any> {
    return this.request('initialize', params);
  }
  
  async hover(params: {
    textDocument: { uri: string };
    position: { line: number; character: number };
  }): Promise<any> {
    return this.request('textDocument/hover', params);
  }
  
  async definition(params: {
    textDocument: { uri: string };
    position: { line: number; character: number };
  }): Promise<any> {
    return this.request('textDocument/definition', params);
  }
  
  async references(params: {
    textDocument: { uri: string };
    position: { line: number; character: number };
    context: { includeDeclaration: boolean };
  }): Promise<any> {
    return this.request('textDocument/references', params);
  }
  
  async completion(params: {
    textDocument: { uri: string };
    position: { line: number; character: number };
  }): Promise<any> {
    return this.request('textDocument/completion', params);
  }
  
  async documentSymbol(params: {
    textDocument: { uri: string };
  }): Promise<any> {
    return this.request('textDocument/documentSymbol', params);
  }
  
  async workspaceSymbol(params: {
    query: string;
  }): Promise<any> {
    return this.request('workspace/symbol', params);
  }
  
  async codeAction(params: {
    textDocument: { uri: string };
    range: {
      start: { line: number; character: number };
      end: { line: number; character: number };
    };
    context: { diagnostics: any[] };
  }): Promise<any> {
    return this.request('textDocument/codeAction', params);
  }
  
  async rename(params: {
    textDocument: { uri: string };
    position: { line: number; character: number };
    newName: string;
  }): Promise<any> {
    return this.request('textDocument/rename', params);
  }
  
  async formatting(params: {
    textDocument: { uri: string };
    options: {
      tabSize: number;
      insertSpaces: boolean;
    };
  }): Promise<any> {
    return this.request('textDocument/formatting', params);
  }
  
  isRunning(): boolean {
    return this.client !== null;
  }
}
