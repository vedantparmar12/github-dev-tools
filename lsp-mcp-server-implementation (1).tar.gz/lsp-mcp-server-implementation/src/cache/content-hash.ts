import * as crypto from 'crypto';

export class ContentHasher {
  static hash(content: string | object): string {
    const str = typeof content === 'string' ? content : JSON.stringify(content);
    return crypto.createHash('sha256').update(str).digest('hex');
  }
  
  static hashFile(filePath: string, content: string): string {
    return this.hash(`${filePath}:${content}`);
  }
  
  static compare(hash1: string, hash2: string): boolean {
    return hash1 === hash2;
  }
}
