import { MultiLayerCache } from './cache/multi-layer-cache';
import { CacheInvalidationManager } from './cache/invalidation';
import { SemanticGraphBuilder } from './graph/semantic-graph';
import { IntelligentWarmup } from './warmup/intelligent-warmup';
import { ResilientLSPManager } from './lsp/resilient-manager';
import { LSPClient } from './lsp/client';
import * as path from 'path';

export async function initializeLSPMCP(workspaceRoot: string) {
  console.log('🚀 Initializing LSP-MCP Server...\n');
  
  // 1. Initialize cache
  console.log('📦 Setting up multi-layer cache...');
  const cache = new MultiLayerCache({
    redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
    diskCachePath: path.join(workspaceRoot, '.lsp-mcp-cache'),
  });
  
  // 2. Initialize LSP client
  console.log('🔌 Connecting to LSP server...');
  const lspClient = new LSPClient({
    command: process.env.LSP_COMMAND || 'typescript-language-server',
    args: ['--stdio'],
    workspaceRoot,
  });
  
  await lspClient.start();
  
  // 3. Wrap with resilience
  console.log('🛡️  Adding resilience layer...');
  const lspManager = new ResilientLSPManager(lspClient, cache);
  
  // 4. Build semantic graph
  console.log('🧠 Building semantic understanding...');
  const graphBuilder = new SemanticGraphBuilder(workspaceRoot);
  
  // 5. Intelligent warm-up
  console.log('⚡ Running intelligent warm-up...');
  const warmup = new IntelligentWarmup(
    workspaceRoot,
    lspClient,
    (progress) => {
      console.log(`  [${progress.phase}] ${progress.progress.toFixed(0)}% (ETA: ${progress.eta}ms)`);
    }
  );
  
  await warmup.warmup();
  
  // 6. Start cache invalidation watcher
  console.log('👁️  Starting file watcher...');
  const invalidator = new CacheInvalidationManager(cache, workspaceRoot);
  invalidator.start();
  
  console.log('\n✅ LSP-MCP Server Ready!\n');
  
  // Return server instance
  return {
    cache,
    lspManager,
    graphBuilder,
    invalidator,
    
    // Shutdown handler
    async shutdown() {
      console.log('Shutting down...');
      invalidator.stop();
      await lspManager.shutdown();
      await cache.close();
    },
    
    // Stats
    getStats() {
      return {
        cache: cache.getStats(),
        lsp: lspManager.getHealthStatus(),
        graph: {
          nodeCount: graphBuilder.graph.size,
          topNodes: graphBuilder.getNodesByImportance(5),
        },
      };
    },
  };
}

// Main entry point
if (require.main === module) {
  const workspaceRoot = process.argv[2] || process.cwd();
  
  initializeLSPMCP(workspaceRoot)
    .then((server) => {
      console.log('Server running. Press Ctrl+C to stop.');
      
      // Show stats every 30 seconds
      setInterval(() => {
        console.log('\n=== Stats ===');
        console.log(JSON.stringify(server.getStats(), null, 2));
      }, 30000);
      
      // Graceful shutdown
      process.on('SIGINT', async () => {
        await server.shutdown();
        process.exit(0);
      });
    })
    .catch((error) => {
      console.error('Failed to start server:', error);
      process.exit(1);
    });
}

export * from './cache/multi-layer-cache';
export * from './graph/semantic-graph';
export * from './lsp/client';
export * from './lsp/resilient-manager';
export * from './warmup/intelligent-warmup';
export * from './optimizer/context-optimizer';
export * from './security/sandbox';
export * from './security/resource-limiter';
export * from './security/auditor';
