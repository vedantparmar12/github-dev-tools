import { SemanticGraphBuilder, SemanticNode } from '../graph/semantic-graph';
import { LSPClient } from '../lsp/client';

export interface ContextPlan {
  primarySymbols: SemanticNode[];
  relatedSymbols: SemanticNode[];
  suggestedActions: string[];
  architecturalContext: string;
}

export interface MCPRequest {
  method: string;
  params: any;
}

export class ContextOptimizer {
  private accessPattern = new Map<string, string[]>();
  
  constructor(
    private graphBuilder: SemanticGraphBuilder,
    private lspClient: LSPClient
  ) {}
  
  async analyzeRequest(request: MCPRequest): Promise<ContextPlan> {
    const plan: ContextPlan = {
      primarySymbols: [],
      relatedSymbols: [],
      suggestedActions: [],
      architecturalContext: '',
    };
    
    // Determine request intent
    const intent = this.classifyIntent(request);
    
    switch (intent) {
      case 'definition':
        return this.planForDefinitionRequest(request);
      
      case 'references':
        return this.planForReferencesRequest(request);
      
      case 'completion':
        return this.planForCompletionRequest(request);
      
      case 'hover':
        return this.planForHoverRequest(request);
      
      default:
        return plan;
    }
  }
  
  private async planForDefinitionRequest(request: MCPRequest): Promise<ContextPlan> {
    const plan: ContextPlan = {
      primarySymbols: [],
      relatedSymbols: [],
      suggestedActions: [],
      architecturalContext: '',
    };
    
    // Extract symbol information from request
    const symbolId = this.extractSymbolId(request);
    if (!symbolId) return plan;
    
    const primaryNode = this.graphBuilder.getNode(symbolId);
    if (!primaryNode) return plan;
    
    plan.primarySymbols = [primaryNode];
    
    // Get related nodes (dependencies and dependents)
    const relatedNodes = this.graphBuilder.getRelatedNodes(symbolId, 2);
    
    const dependencies = relatedNodes.filter(n => 
      primaryNode.dependencies.includes(n.id)
    );
    const dependents = relatedNodes.filter(n => 
      primaryNode.dependents.includes(n.id)
    );
    
    plan.relatedSymbols = [...dependencies, ...dependents];
    
    // Generate suggestions
    if (dependents.length > 10) {
      plan.suggestedActions.push(
        'This is a heavily used symbol. Consider backward compatibility when making changes.'
      );
    }
    
    if (primaryNode.metadata.complexity > 10) {
      plan.suggestedActions.push(
        'High complexity detected. Consider refactoring to improve maintainability.'
      );
    }
    
    if (primaryNode.metadata.layer) {
      plan.suggestedActions.push(
        `This symbol is in the ${primaryNode.metadata.layer} layer. Ensure dependencies respect architectural boundaries.`
      );
    }
    
    // Generate architectural context
    plan.architecturalContext = this.generateArchitecturalContext(primaryNode);
    
    return plan;
  }
  
  private async planForReferencesRequest(request: MCPRequest): Promise<ContextPlan> {
    const plan: ContextPlan = {
      primarySymbols: [],
      relatedSymbols: [],
      suggestedActions: ['Pre-fetching common usage patterns'],
      architecturalContext: 'Analyzing symbol usage across codebase',
    };
    
    // TODO: Pre-fetch usage patterns
    
    return plan;
  }
  
  private async planForCompletionRequest(request: MCPRequest): Promise<ContextPlan> {
    const plan: ContextPlan = {
      primarySymbols: [],
      relatedSymbols: [],
      suggestedActions: ['Analyzing context for relevant completions'],
      architecturalContext: 'Considering current scope and imports',
    };
    
    // TODO: Analyze completion context
    
    return plan;
  }
  
  private async planForHoverRequest(request: MCPRequest): Promise<ContextPlan> {
    const plan: ContextPlan = {
      primarySymbols: [],
      relatedSymbols: [],
      suggestedActions: [],
      architecturalContext: '',
    };
    
    // For hover, we might want to pre-fetch related type information
    
    return plan;
  }
  
  private classifyIntent(request: MCPRequest): string {
    const method = request.method.toLowerCase();
    
    if (method.includes('definition')) return 'definition';
    if (method.includes('references')) return 'references';
    if (method.includes('completion')) return 'completion';
    if (method.includes('hover')) return 'hover';
    
    return 'unknown';
  }
  
  private extractSymbolId(request: MCPRequest): string | undefined {
    // This would extract the symbol identifier from the request
    // For now, returning undefined as it depends on the request structure
    return undefined;
  }
  
  private generateArchitecturalContext(node: SemanticNode): string {
    let context = `Symbol: ${node.name}\n`;
    context += `Type: ${node.type}\n`;
    context += `Layer: ${node.metadata.layer || 'unknown'}\n`;
    context += `Importance: ${node.metadata.importance.toFixed(3)}\n`;
    context += `Complexity: ${node.metadata.complexity}\n`;
    context += `Dependencies: ${node.dependencies.length}\n`;
    context += `Dependents: ${node.dependents.length}\n`;
    
    if (node.metadata.layer) {
      context += `\nArchitectural Note: This symbol is in the ${node.metadata.layer} layer. `;
      
      if (node.metadata.layer === 'ui') {
        context += 'It should only depend on service layer, not data layer directly.';
      } else if (node.metadata.layer === 'service') {
        context += 'It orchestrates business logic and coordinates between UI and data layers.';
      } else if (node.metadata.layer === 'data') {
        context += 'It handles data persistence and should be framework-agnostic.';
      } else if (node.metadata.layer === 'util') {
        context += 'It provides utility functions that can be used across all layers.';
      }
    }
    
    return context;
  }
  
  // Predictive pre-fetching
  recordAccess(symbolId: string, nextSymbolId: string): void {
    const pattern = this.accessPattern.get(symbolId) || [];
    pattern.push(nextSymbolId);
    
    // Keep only recent patterns (last 100)
    if (pattern.length > 100) {
      pattern.shift();
    }
    
    this.accessPattern.set(symbolId, pattern);
  }
  
  predictNext(symbolId: string): string[] {
    const pattern = this.accessPattern.get(symbolId) || [];
    
    // Count frequency of each next symbol
    const frequency = new Map<string, number>();
    for (const next of pattern) {
      frequency.set(next, (frequency.get(next) || 0) + 1);
    }
    
    // Sort by frequency
    return Array.from(frequency.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([id]) => id)
      .slice(0, 5); // Top 5 predictions
  }
}
