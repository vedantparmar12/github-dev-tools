import * as fs from 'fs/promises';
import * as path from 'path';

export interface ResourceUsage {
  memoryBytes: number;
  memoryPercent: number;
  cpuPercent: number;
  openFiles: number;
}

export class ResourceLimiter {
  private pid: number;
  private maxMemoryBytes: number;
  private checkInterval: NodeJS.Timeout | null = null;
  private onLimitExceeded?: (resource: string, usage: ResourceUsage) => void;
  
  constructor(
    pid: number,
    maxMemoryMB: number = 2048,
    onLimitExceeded?: (resource: string, usage: ResourceUsage) => void
  ) {
    this.pid = pid;
    this.maxMemoryBytes = maxMemoryMB * 1024 * 1024;
    this.onLimitExceeded = onLimitExceeded;
  }
  
  start(): void {
    this.checkInterval = setInterval(() => {
      this.checkResources();
    }, 5000); // Check every 5 seconds
  }
  
  stop(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
  }
  
  private async checkResources(): Promise<void> {
    try {
      const usage = await this.getResourceUsage();
      
      if (usage.memoryBytes > this.maxMemoryBytes) {
        console.error(
          `Memory limit exceeded: ${(usage.memoryBytes / 1024 / 1024).toFixed(0)}MB > ${(this.maxMemoryBytes / 1024 / 1024).toFixed(0)}MB`
        );
        
        if (this.onLimitExceeded) {
          this.onLimitExceeded('memory', usage);
        }
      }
      
      if (usage.cpuPercent > 80) {
        console.warn(
          `High CPU usage: ${usage.cpuPercent.toFixed(1)}%`
        );
      }
      
      if (usage.openFiles > 900) {
        console.warn(
          `High file descriptor usage: ${usage.openFiles}`
        );
      }
    } catch (error) {
      console.error('Failed to check resources:', error);
    }
  }
  
  async getResourceUsage(): Promise<ResourceUsage> {
    const memUsage = process.memoryUsage();
    
    return {
      memoryBytes: memUsage.heapUsed,
      memoryPercent: (memUsage.heapUsed / memUsage.heapTotal) * 100,
      cpuPercent: await this.getCPUUsage(),
      openFiles: await this.getOpenFileCount(),
    };
  }
  
  private async getCPUUsage(): Promise<number> {
    // Get CPU usage for the process
    const usage = process.cpuUsage();
    const totalUsage = (usage.user + usage.system) / 1000000; // Convert to seconds
    
    // This is a simplified calculation
    // In production, you'd want to track delta over time
    return Math.min(100, totalUsage);
  }
  
  private async getOpenFileCount(): Promise<number> {
    try {
      // On Linux, check /proc/[pid]/fd
      const fdPath = `/proc/${this.pid}/fd`;
      const files = await fs.readdir(fdPath);
      return files.length;
    } catch {
      // On other platforms, this won't work
      return 0;
    }
  }
  
  // cgroups integration (Linux only)
  async setupCGroups(groupName: string): Promise<void> {
    const cgroupPath = `/sys/fs/cgroup/${groupName}`;
    
    try {
      // Create cgroup directory
      await fs.mkdir(cgroupPath, { recursive: true });
      
      // Set memory limit
      await fs.writeFile(
        path.join(cgroupPath, 'memory.max'),
        String(this.maxMemoryBytes)
      );
      
      // Set CPU limit (50% of one core = 50ms per 100ms period)
      await fs.writeFile(
        path.join(cgroupPath, 'cpu.max'),
        '50000 100000'
      );
      
      // Add process to cgroup
      await fs.writeFile(
        path.join(cgroupPath, 'cgroup.procs'),
        String(this.pid)
      );
      
      console.log(`Process ${this.pid} added to cgroup ${groupName}`);
    } catch (error) {
      console.error('Failed to setup cgroups:', error);
      console.warn('Resource limits via cgroups not available. Using monitoring only.');
    }
  }
  
  async getCGroupStats(groupName: string): Promise<any> {
    const cgroupPath = `/sys/fs/cgroup/${groupName}`;
    
    try {
      const memoryUsage = await fs.readFile(
        path.join(cgroupPath, 'memory.current'),
        'utf-8'
      );
      
      const cpuStats = await fs.readFile(
        path.join(cgroupPath, 'cpu.stat'),
        'utf-8'
      );
      
      return {
        memoryBytes: parseInt(memoryUsage),
        cpuStats: this.parseCpuStats(cpuStats),
      };
    } catch (error) {
      console.error('Failed to get cgroup stats:', error);
      return null;
    }
  }
  
  private parseCpuStats(stats: string): Record<string, number> {
    const lines = stats.split('\n');
    const parsed: Record<string, number> = {};
    
    for (const line of lines) {
      const [key, value] = line.split(' ');
      if (key && value) {
        parsed[key] = parseInt(value);
      }
    }
    
    return parsed;
  }
}
